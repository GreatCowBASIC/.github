/* fB resource hack - fake windows.h to include relevant headers
 * DrV - 10-Feb-2005
 */

#include "winuser.h"
#include "winnt.h"
#include "winver.h"
#include "dde.h"
#include "dlgs.h"
#include "commctrl.h"
