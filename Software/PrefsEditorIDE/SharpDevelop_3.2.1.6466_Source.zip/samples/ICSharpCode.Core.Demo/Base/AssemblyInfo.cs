﻿/*
 * Created by SharpDevelop.
 * User: Daniel Grunwald
 * Date: 22.12.2005
 * Time: 19:32
 */

using System.Reflection;
using System.Runtime.CompilerServices;

// Information about this assembly is defined by the following
// attributes.
//
// change them to the information which is associated with the assembly
// you compile.

[assembly: AssemblyTitle("Base")]
[assembly: AssemblyDescription("Base AddIn for ICSharpCode.Core.Demo")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("ic#code")]
[assembly: AssemblyProduct("ICSharpCode.Core.Demo")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// The assembly version has following format :
//
// Major.Minor.Build.Revision
//
// You can specify all values by your own or you can build default build and revision
// numbers with the '*' character (the default):

[assembly: AssemblyVersion("1.0.*")]

