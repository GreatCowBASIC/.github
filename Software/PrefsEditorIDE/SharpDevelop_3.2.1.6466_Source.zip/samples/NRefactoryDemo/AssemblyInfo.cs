﻿using System.Reflection;
using System.Runtime.CompilerServices;

// Information about this assembly is defined by the following
// attributes.
//
// change them to the information which is associated with the assembly
// you compile.

[assembly: AssemblyTitle("NRefactory Demo")]
[assembly: AssemblyDescription("Graphical application to demonstrate NRefactory")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("icsharpcode.net")]
[assembly: AssemblyProduct("SharpDevelop")]
[assembly: AssemblyCopyright("2006, Daniel Grunwald")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// The assembly version has following format :
//
// Major.Minor.Build.Revision
//
// You can specify all values by your own or you can build default build and revision
// numbers with the '*' character (the default):

[assembly: AssemblyVersion("1.0.*")]

