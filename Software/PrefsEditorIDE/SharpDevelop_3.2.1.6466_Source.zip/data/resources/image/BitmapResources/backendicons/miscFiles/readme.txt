HTML, ASP, XML, TXT, CSS, DTD, XSD and XSL icons by
  Wolfgang Bartelme   http://www.bartelme.at/
